const express =require("express");
const bodyParser =require('body-parser');
const app=express();
const cors =require('cors');
const mysql =require('mysql');

const db=mysql.createPool({
    host: 'localhost',
    user: 'root',
    password:'root',
    database:'qryde'
})
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({extended: true}))

app.post('/api/get',(req,res)=>{

    const sqls="SELECT * FROM qrydedata;"
     
    db.query(sqls,(err,result)=>{
       console.log(err);
        res.send(result);
    });

})

// For viewing data from the database



app.post("/api/insert", (req,res)=>{

    const val=req.body.val;
    const sqli="INSERT INTO qrydedata VALUES (?, ?, ?, ?, ?, ?);"
    console.log(req.body.val);
    
    db.query(sqli,[val.custname,val.featureid,val.featurevalue,val.featuredesc,val.featureallowed,val.featureinternal],(err,result)=>{
        console.log("errrr",err);
        if(!err)
        {
            res.send("success");
        }
       
    });

});
// for inserting data into the data base
app.delete("/api/delete/:val",(req,res)=>{
   const n=req.params.val;
   const sqld="DELETE FROM qrydedata WHERE featureid= ?";

   db.query(sqld,n,(err,result)=>{
    console.log(err);
    if(!err)
    {
        res.send(n);
    }
   })
})
// For deleting the data from the data base
app.put("/api/update",(req,res)=>{
    const n=req.body.old;
    const q=req.body.ne;
    console.log("new",n);
    console.log("old",q);
    const sqlu="UPDATE  qrydedata SET custname= ?, featureid = ?, featurevalue =? , featuredesc =? ,featureallowed =? , featureinternal =?  WHERE featureid= ?";
     
    db.query(sqlu,[q.custname,q.featureid,q.featurevalue,q.featuredesc,q.featureallowed,q.featureinternal,n.featureid],(err,result)=>{
        console.log(err);
        if(!err)
    {
        res.send(n);
    }
    })
 })
// For updating the data into the data base
app.listen(3001,()=>{
    console.log("runhn");
})