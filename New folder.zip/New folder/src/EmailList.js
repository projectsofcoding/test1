import { Checkbox, IconButton } from '@material-ui/core'
import { ArrowDropDown } from '@material-ui/icons'
import React from 'react'
import './EmailList.css'
import Section from './Section'
import InboxIcon from '@material-ui/icons/Inbox';
import AssignmentIcon from '@material-ui/icons/Assignment';
import EmailRow from './EmailRow'

function EmailList() {
    return (
        <div className='emailList'>
            <div className="emailList__settings">
                <div className="emailList__settingsLeft">
                    <Checkbox />
                    <IconButton>
                        <ArrowDropDown />
                    </IconButton>
                   
                </div>

            </div>
            
           <div className="emailList__sections">
               <Section Icon={ InboxIcon} title ='Messages'color='green' selected />
               <Section Icon={ AssignmentIcon } title ='Guidelines'color='green' selected />
               <Section Icon={ InboxIcon} title ='Tab3'color='green' selected />
               </div>
               <div className="emailList__List">
                   <EmailRow
                   title="Twitch"
                   subject="Hey follow me"
                   description=" This is a demo"
                   time="10pm"
                   />
                   <EmailRow
                   title="Amazon"
                   subject="Order Placed"
                   description=" Reaching soon"
                   time="10pm"
                   />
                   <EmailRow
                   title="Contract"
                   subject="Sign the Contract"
                   description="sign it asap"
                   time="10pm"
                   />

               </div>
        </div>
    )
}

export default EmailList
