import { Button, IconButton } from '@material-ui/core';
import React from 'react'
import AddIcon from '@material-ui/icons/Add';
import "./Sidebar.css";
import ListAltIcon from '@material-ui/icons/ListAlt';
import SidebarOption from './SidebarOption'
import HistoryIcon from '@material-ui/icons/History';
import SendIcon from '@material-ui/icons/Send';
import PhoneIcon from '@material-ui/icons/Phone';
import DuoIcon from '@material-ui/icons/Duo';
function Sidebar() {
    return (
        <div className="sidebar">
            <Button startIcon={<AddIcon fontsize="large" />} className="sidebar__compose">
                Compose</Button>
                <SidebarOption Icon={ListAltIcon} title="Forms" number={40} selected={true}/>
                <SidebarOption Icon={HistoryIcon} title="Activity" number={10} />
                <SidebarOption Icon={SendIcon} title="Send" number={2} />

                <div className="sidebar__footer">
                    <div className="sidebar__footerIcons">
                        <IconButton>
                            <PhoneIcon />
                    
                        </IconButton>
                        <IconButton>
                            <DuoIcon />
                        </IconButton>
                    </div>
                    </div>
        </div>
    )
}

export default Sidebar
